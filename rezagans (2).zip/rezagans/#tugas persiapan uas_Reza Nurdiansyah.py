#tugas persiapan uas
# 1. 
total = 0
for i in range(1, 8):
    total += i**2
print("Hasil penjumlahan kuadrat angka 1 hingga 7:",total)

# 2. 
def hitung_luas_lingkaran(jari_jari):
    return 3.14 * jari_jari**2
jari_jari = float(input("Masukkan jari-jari lingkaran: "))
luas_lingkaran = hitung_luas_lingkaran(jari_jari)
print("Luas lingkaran adalah:", luas_lingkaran)


# # 3. 
kendaraan_list = ["Mobil", "Motor", "Sepeda", "Bus", "Truk"]
for kendaraan in kendaraan_list:
    print(kendaraan)

# # 4. 
karyawan = {
    'karyawan1': {'nama': 'Jono', 'id_karyawan': '001', 'jabatan': 'Manager'},
    'karyawan2': {'nama': 'udin', 'id_karyawan': '002', 'jabatan': 'admin'},
    'karyawan3': {'nama': 'asep', 'id_karyawan': '003', 'jabatan': 'pengacara'},
  
}

karyawan['karyawan1']['gaji'] = 80000
karyawan['karyawan2']['gaji'] = 60000
karyawan['karyawan3']['gaji'] = 10000
for karyawan_id, info in karyawan.items():
    print(f"ID Karyawan: {info['id_karyawan']}, Nama: {info['nama']}, Jabatan: {info['jabatan']}, Gaji: {info['gaji']}")

# # 5. 
class Lingkaran:
    def init(self, jari_jari):
        self.jari_jari = jari_jari

    def hitung_luas(self):
        return 3.14 * self.jari_jari**2

jari_jari = float(input("Masukkan nilai jari-jari lingkaran: "))
lingkaran = Lingkaran(jari_jari)
luas_lingkaran = lingkaran.hitung_luas()
print("Luas lingkaran dengan jari-jari", jari_jari, "adalah",luas_lingkaran)